/* ── Backend + account session ─────────────────────────────────────
   DEFAULT_API_BASE must point at your deployed backend before you
   publish (your Vercel URL, e.g. https://cj-product-hunter.vercel.app).
   While testing locally it stays http://localhost:3000 — a one-off
   override without editing this file:
     chrome.storage.local.set({ apiBase: "https://your-app.vercel.app" })
*/
const DEFAULT_API_BASE = "https://cj-winning-product-hunter-poc.vercel.app";
let API_BASE = DEFAULT_API_BASE;

const TOKEN_STORAGE_KEY = "cjToken";
let token = "";
let session = null;
let authMode = "signin";

const statusEl = document.querySelector("#status");
const messageEl = document.querySelector("#message");
const resultsEl = document.querySelector("#results");
const form = document.querySelector("#searchForm");
const queryInput = document.querySelector("#query");
const searchButton = document.querySelector("#searchButton");
const trendingButton = document.querySelector("#trendingButton");
const bestSellingButton = document.querySelector("#bestSellingButton");
const bestSellerSupplierButton = document.querySelector("#bestSellerSupplierButton");
const bestSellerCountrySelect = document.querySelector("#bestSellerCountry");
const countryFilterBar = document.querySelector("#countryFilterBar");
const resetFiltersButton = document.querySelector("#resetFilters");
const themeToggle = document.querySelector("#themeToggle");
const modal = document.querySelector("#detailModal");
const modalBody = document.querySelector("#modalBody");
const modalClose = document.querySelector("#modalClose");

const authOverlay = document.querySelector("#authOverlay");
const appEl = document.querySelector("#app");
const authMsg = document.querySelector("#authMsg");
const authBtn = document.querySelector("#authBtn");
const toggleAuthBtn = document.querySelector("#toggleAuth");
const authSwitchText = document.querySelector("#authSwitchText");
const nameWrap = document.querySelector("#nameWrap");
const blockedMsgEl = document.querySelector("#blockedMsg");
const userEmailEl = document.querySelector("#userEmail");
const logoutBtn = document.querySelector("#logoutBtn");

// Every backend call goes through api(): it injects the session token and
// sends the user back to the sign-in screen when the session dies.
async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;
  let res;
  try {
    console.log(`[api] ${options.method || 'GET'} ${API_BASE}${path}`, headers.Authorization ? 'with token' : 'no token');
    res = await fetch(`${API_BASE}${path}`, { ...options, headers });
    console.log(`[api] response:`, res.status, res.statusText);
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error(`[api] error body:`, text);
      throw new Error(`HTTP ${res.status}: ${text || res.statusText}`);
    }
  } catch (err) {
    console.error(`[api] fetch failed:`, err && err.message ? err.message : String(err));
    throw new Error(`Network error: ${err && err.message ? err.message : String(err)}. Check console.`);
  }
  if (res.status === 401) {
    await forgetSession();
    showAuth("Your session expired. Please sign in again.");
    throw new Error("Session expired — please sign in again.");
  }
  return res;
}

let enrichMap = {};
let pendingEnrich = new Set();
let shownProducts = [];
let bestSellingMode = false;
let searchGen = 0;
let currentPage = 1;
let totalPages = 1;
let lastSearchParams = {};

// ── Account / sign-in UI ────────────────────────────────────────
function setAuthMessage(text, ok) {
  if (!authMsg) return;
  authMsg.textContent = text || "";
  authMsg.className = "auth-msg" + (ok ? " ok" : "");
}

function setAuthMode(next) {
  authMode = next;
  const signingUp = authMode === "signup";
  if (authBtn) authBtn.textContent = signingUp ? "Create account" : "Sign in";
  if (authSwitchText) authSwitchText.textContent = signingUp ? "Already have an account?" : "Don't have an account?";
  if (toggleAuthBtn) toggleAuthBtn.textContent = signingUp ? "Sign in" : "Sign up";
  if (nameWrap) nameWrap.hidden = !signingUp;
  const pwd = document.querySelector("#authPassword");
  if (pwd) pwd.autocomplete = signingUp ? "new-password" : "current-password";
  setAuthMessage("");
}

function showAuth(message) {
  if (authOverlay) authOverlay.hidden = false;
  if (appEl) appEl.classList.add("hidden");
  if (resultsEl) resultsEl.innerHTML = "";
  if (message) setAuthMessage(message, false);
}

function hideAuth() {
  if (authOverlay) authOverlay.hidden = true;
  if (appEl) appEl.classList.remove("hidden");
}

async function forgetSession() {
  token = "";
  session = null;
  try {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY]);
  } catch {
    /* storage unavailable */
  }
}

async function saveSession(value) {
  token = value;
  try {
    await chrome.storage.local.set({ [TOKEN_STORAGE_KEY]: value });
  } catch {
    /* storage unavailable */
  }
}

async function fetchMe() {
  try {
    console.log('[fetchMe] calling /api/auth/me with token:', token ? token.substring(0, 30) + '...' : 'NONE');
    const res = await api("/api/auth/me");
    console.log('[fetchMe] response ok:', res.ok, res.status);
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.warn("[fetchMe] non-ok response:", res.status, text);
      return null;
    }
    const data = await res.json();
    console.log('[fetchMe] success:', data);
    return data;
  } catch (err) {
    console.warn("[fetchMe] caught error:", err && err.message ? err.message : String(err));
    return null;
  }
}

function applyAccessState(me) {
  const blocked = Boolean(me.isBlocked);
  const features = me.features || {};
  const canSearch = !blocked && features.search !== false;
  if (blockedMsgEl) {
    blockedMsgEl.classList.toggle("hidden", !blocked);
    blockedMsgEl.textContent = blocked
      ? "🚫 Your account has been suspended. Contact support to restore access."
      : "";
  }
  [searchButton, trendingButton, bestSellingButton, bestSellerSupplierButton].forEach((el) => {
    if (el) el.disabled = !canSearch;
  });
  if (me.dailyLimit && me.dailyUsed >= me.dailyLimit) {
    setStatus("Daily API limit reached", "warn");
    setMessage(`Daily limit reached (${me.dailyUsed}/${me.dailyLimit}). It resets at 00:00 UTC.`, true);
  }
}

function usageSummary() {
  if (!session) return "";
  const bits = [];
  if (session.dailyLimit) bits.push(`today ${session.dailyUsed}/${session.dailyLimit}`);
  if (session.monthlyLimit) bits.push(`month ${session.monthlyUsed}/${session.monthlyLimit}`);
  return bits.length ? ` · ${bits.join(" · ")}` : "";
}

function enterApp(me) {
  session = me;
  hideAuth();
  if (userEmailEl) {
    userEmailEl.textContent = me.email || "";
    userEmailEl.title = `${me.email || ""}\nUser: ${me.id || ""}`;
  }
  applyAccessState(me);
  if (me.isBlocked) return;
  if (me.hasCjKey) {
    setStatus(`Ready · CJ key connected${usageSummary()}`, "ok");
    const stored = chrome.storage.local.get(["lastQuery"]);
    Promise.resolve(stored).then((data) => {
      if (data && data.lastQuery && queryInput && !queryInput.value) queryInput.value = data.lastQuery;
    });
  } else {
    setStatus("Add your CJ API key", "warn");
    setMessage("One-time setup: paste your CJdropshipping API key below.", false);
    openSettings();
  }
}

async function submitAuth() {
  const emailInput = document.querySelector("#authEmail");
  const passwordInput = document.querySelector("#authPassword");
  const email = emailInput ? emailInput.value.trim() : "";
  const password = passwordInput ? passwordInput.value : "";
  if (!email || !password) { setAuthMessage("Enter your email and password."); return; }
  if (authMode === "signup" && password.length < 8) {
    setAuthMessage("Password must be at least 8 characters.");
    return;
  }

  if (authBtn) authBtn.disabled = true;
  setAuthMessage(authMode === "signup" ? "Creating your account…" : "Signing in…");
  try {
    const nameInput = document.querySelector("#authName");
    const res = await fetch(`${API_BASE}/api/auth/${authMode === "signup" ? "signup" : "login"}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        password,
        fullName: nameInput && !nameWrap?.hidden ? nameInput.value.trim() : undefined
      })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Could not sign in.");

    if (authMode === "signup" && !data.token) {
      setAuthMessage("Account created ✓ — confirm your email, then sign in.", true);
      setAuthMode("signin");
      return;
    }

    await saveSession(data.token);
    const me = await fetchMe();
    if (!me) {
      const detail = `API returned no profile data (status: ${data.token ? 'unknown' : 'none'}). Check console in chrome://extensions/ → Inspect for details.`;
      throw new Error("Signed in, but the account could not be loaded.\n" + detail);
    }
    enterApp(me);
  } catch (error) {
    setAuthMessage(error.message || "Could not sign in.");
  } finally {
    if (authBtn) authBtn.disabled = false;
  }
}

if (authBtn) authBtn.addEventListener("click", submitAuth);
if (toggleAuthBtn) {
  toggleAuthBtn.addEventListener("click", () => {
    setAuthMode(authMode === "signin" ? "signup" : "signin");
  });
}
if (authOverlay) {
  authOverlay.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      submitAuth();
    }
  });
}
if (logoutBtn) {
  logoutBtn.addEventListener("click", async () => {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch {
      /* token already dead */
    }
    await forgetSession();
    showAuth();
    setStatus("Signed out", "warn");
    setMessage("", false);
  });
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}

function setStatus(text, tone) {
  statusEl.textContent = text;
  statusEl.className = "status" + (tone ? ` ${tone}` : "");
}

function setMessage(text, isError) {
  messageEl.textContent = text || "";
  messageEl.className = "message" + (isError ? " error" : "");
}

function formatListingAge(days, createrTime) {
  const d = Number(days) || 0;
  const months = Math.floor(d / 30);
  const years = Math.floor(d / 365);
  if (years > 0) return `${years} year(s) ago`;
  if (months > 0) return `${months} month(s) ago`;
  return `${d} day(s) ago`;
}

function scoreClass(score) {
  if (score >= 70) return "high";
  if (score >= 45) return "mid";
  return "low";
}

function inputValue(id) {
  const el = document.querySelector(id);
  return el ? String(el.value || "").trim() : "";
}

function readFilters() {
  const freeShip = document.querySelector("#fFreeShip");
  const quick = document.querySelector("#fQuickDelivery");
  return {
    minPrice: inputValue("#fMinPrice"),
    maxPrice: inputValue("#fMaxPrice"),
    minStock: inputValue("#fMinStock"),
    maxStock: inputValue("#fMaxStock"),
    minListed: inputValue("#fMinListed"),
    maxListed: inputValue("#fMaxListed"),
    country: inputValue("#fCountry"),
    deliverTo: inputValue("#fDeliverTo"),
    freeShipping: freeShip && freeShip.checked ? "1" : "",
    quick: quick && quick.checked ? "1" : ""
  };
}

function readListingFilters() {
  const ck = (id) => {
    const el = document.querySelector(id);
    return Boolean(el && el.checked);
  };
  return {
    newListing: ck("#fNewListing"),
    newProduct: ck("#fNewProduct"),
    reListing: ck("#fRelisting"),
    neverListed: ck("#fNeverListed"),
    quickDelivery: ck("#fQuickDelivery")
  };
}

function applyListingFilters(products) {
  const f = readListingFilters();
  const needsMeta = f.newListing || f.newProduct || f.reListing;
  // Max days since listed — read from the DOM directly (not part of readListingFilters)
  const maxDaysInput = document.querySelector("#fMaxDays");
  const maxDays = maxDaysInput ? Number(maxDaysInput.value) || 0 : 0;
  return products.filter((p) => {
    if (f.neverListed && !(Number(p.listedNum) === 0)) return false;
    if (f.quickDelivery && p.quickDelivery !== true) return false;
    const en = enrichMap[p.id];
    const daysOld = en && en.daysSinceListing !== null && en.daysSinceListing !== undefined && Number.isFinite(Number(en.daysSinceListing))
      ? Number(en.daysSinceListing)
      : null;
    // Max days since listed (requires enrichment data)
    if (maxDays && daysOld !== null && daysOld > maxDays) return false;
    if (maxDays && daysOld === null) return false; // can't verify age — exclude
    if (!needsMeta && !maxDays) return true;
    if (daysOld === null) return false;
    if (f.newListing && !(daysOld <= 7)) return false;
    if (f.newProduct && !(daysOld <= 30)) return false;
    if (f.reListing && en.isRelisting !== true) return false;
    return true;
  });
}

/* ── Client-side stock & seller-listings range filters ─────────── */
function applyRangeFilters(products) {
  const f = readFilters();
  const minS = Number(f.minStock) || 0;
  const maxS = Number(f.maxStock) || 0;
  const minL = Number(f.minListed) || 0;
  const maxL = Number(f.maxListed) || 0;
  return products.filter((p) => {
    const stock = Number(p.stock) || 0;
    const listed = Number(p.listedNum) || 0;
    if (minS && stock < minS) return false;
    if (maxS && stock > maxS) return false;
    if (minL && listed < minL) return false;
    if (maxL && listed > maxL) return false;
    return true;
  });
}

function buildParams(extra = {}) {
  const params = new URLSearchParams({
    q: queryInput.value.trim(),
    page: String(currentPage),
    pageSize: "50",
    sort: "winning",
    ...extra
  });
  const f = readFilters();
  if (f.minPrice) params.set("minPrice", f.minPrice);
  if (f.maxPrice) params.set("maxPrice", f.maxPrice);
  if (f.minStock) params.set("minStock", f.minStock);
  if (f.minListed) params.set("minListed", f.minListed);
  if (f.maxListed) params.set("maxListed", f.maxListed);
  if (f.country) params.set("country", f.country);
  if (f.deliverTo) params.set("deliverTo", f.deliverTo);
  if (f.quick) {
    params.set("quick", "1");
    params.set("deliverTo", f.deliverTo || "US");
  }
  if (f.freeShipping) params.set("freeShipping", f.freeShipping);
  return params;
}

function formatCost(p) {
  if (p.cjCost === null || p.cjCost === undefined) return "n/a";
  const promo = p.promoPrice !== null && p.promoPrice !== undefined && p.promoPrice < p.cjCost;
  const base = `${escapeHtml(p.currency)} ${Number(p.cjCost).toFixed(2)}`;
  return promo ? `${base} → ${Number(p.promoPrice).toFixed(2)}` : base;
}

function calculateProfit(p, en) {
  const cjCost = Number(p?.cjCost) || 0;
  const sellPrice = Number(p?.suggestSellPrice) || Number(p?.cjCost) * 1.5 || 0;
  const totalSales = Number(en?.totalSales) || 0;
  const dailyEst = Number(en?.dailyEst) || 0;
  const revenue = sellPrice * (dailyEst * 30 || totalSales || 100);
  const grossProfit = revenue - (cjCost * (dailyEst * 30 || totalSales || 100));
  const netProfit = grossProfit - 5;
  const margin = revenue > 0 ? Math.round(((netProfit / revenue) * 100) * 100) / 100 : 0;
  return { revenue, grossProfit, netProfit, margin };
}

function profitRowsHtml(p, en) {
  const calc = calculateProfit(p, en);
  if (!calc || !calc.margin) return "";
  const revenue = "$" + calc.revenue.toFixed(2);
  const profit = "$" + calc.netProfit.toFixed(2);
  const margin = calc.margin;
  const marginClass = margin > 30 ? "profit-good" : margin > 15 ? "profit-moderate" : "profit-low";
  return `<div class="row tags profit-section"><span>💰 Est. revenue ${revenue}</span><span>✅ Est. profit ${profit}</span><span class="profit-margin ${marginClass}">📈 ${margin}% margin</span></div>`;
}

function salesRowsHtml(p) {
  const en = enrichMap[p.id];
  if (en) {
    const sold = en.totalSales !== null && en.totalSales !== undefined
      ? Number(en.totalSales).toLocaleString() : "—";
    const bits = [];
    if (en.rating !== null && en.rating !== undefined) bits.push(`⭐ ${escapeHtml(en.rating)}/5`);
    if (en.reviewTotal !== null && en.reviewTotal !== undefined) bits.push(`${Number(en.reviewTotal).toLocaleString()} reviews`);
    const est = [];
    if (en.dailyEst !== null && en.dailyEst !== undefined) est.push(`📈 ~${Number(en.dailyEst).toLocaleString()}/day`);
    if (en.monthlyEst !== null && en.monthlyEst !== undefined) est.push(`📊 ~${Number(en.monthlyEst).toLocaleString()}/mo`);
    const flags = [];
    if (en.daysSinceListing !== null && en.daysSinceListing !== undefined) {
      const d = Number(en.daysSinceListing);
      flags.push(`📅 listed ${d.toLocaleString()}d ago${d <= 7 ? " 🆕" : d <= 30 ? " ✨" : ""}`);
    }
    if (en.isNewListing === true) flags.push("🆕 listing ≤7d");
    if (en.isNewProduct === true && en.isNewListing !== true) flags.push("✨ new ≤30d");
    if (en.isRelisting === true) flags.push("♻ re-listing");
    return `
      <div class="row tags"><span>🛒 Sold ${sold}</span>${bits.length ? `<span>${bits.join(" · ")}</span>` : ""}</div>
      ${est.length ? `<div class="row tags">${est.join("")}<span>estimate</span></div>` : ""}
      ${flags.length ? `<div class="row tags">${flags.map((f) => `<span>${f}</span>`).join("")}</div>` : ""}
      ${en && calculateProfit(p, en)?.margin > 0 ? profitRowsHtml(p, en) : ""}
      ${en.daysSinceListing !== null && en.daysSinceListing !== undefined ? `<div class="row tags"><span>📅 First listed: ${formatListingAge(en.daysSinceListing, en.createrTime)}</span><button type="button" class="view-analysis-btn" title="View listing details">📅 Listing age →</button></div>` : ""}`;
  }
  if (pendingEnrich.has(p.id)) return `<div class="row tags"><span>⏳ sales & ratings…</span></div>`;
  return "";
}

function renderProducts(products) {
  shownProducts = products;
  resultsEl.innerHTML = "";
  if (!products.length) {
    setMessage("No products found. Try a broader keyword, Trending mode, or looser filters.", false);
    return;
  }
  const sortLabel = bestSellingMode ? "sorted by total sold (CJ orders)" : "sorted by winning score";
  setMessage(`${products.length} product(s), ${sortLabel}. Click a product to open it on CJ.`, false);
  products.forEach((p) => {
    const item = document.createElement("article");
    item.className = "item";
    const stock = p.stock === null || p.stock === undefined ? "?" : String(p.stock);
    const listed = p.listedNum === null || p.listedNum === undefined ? "listing ?" : `🏪 ${Number(p.listedNum).toLocaleString()} sellers`;
    const en = enrichMap[p.id] || {};
    const tags = [
      listed,
      `stock ${stock}`,
      p.deliveryDays !== null && p.deliveryDays !== undefined
        ? `<span class="qbadge">🚀 ~${p.deliveryDays}d delivery</span>`
        : p.quickDelivery ? `<span class="qbadge">🚀 quick delivery</span>` : null,
      p.isFreeShipping ? "free ship" : null,
      p.hasVideo ? "video" : null,
      en.daysSinceListing !== null && en.daysSinceListing !== undefined
        ? `<span class="qbadge">📅 listed ${Number(en.daysSinceListing).toLocaleString()}d ago</span>`
        : null,
      p.supplierName ? `supplier: ${escapeHtml(p.supplierName)}` : null,
      p.category ? escapeHtml(p.category) : null
    ].filter(Boolean).map(t => t.startsWith("<span") ? t : `<span>${t}</span>`).join("");
    const img = p.image
      ? `<img src="${escapeHtml(p.image)}" alt="" loading="lazy">`
      : `<div class="noimg">No img</div>`;
    item.innerHTML = `
      ${img}
      <div class="body">
        <h3 title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</h3>
        <div class="row cost"><strong>CJ cost ${formatCost(p)}</strong></div>
        <div class="row tags">${tags}</div>
        ${salesRowsHtml(p)}
        <div class="row">
          <span class="score ${scoreClass(Number(p.score) || 0)}">${escapeHtml(p.score)}/100</span>
          <span class="label">${escapeHtml(p.scoreLabel)}</span>
          <button type="button" class="info-btn list-btn" title="List this product to your CJ store">🏪 List to CJ</button>
          <button type="button" class="info-btn" title="View supplier & product details">Supplier info</button>
          <button type="button" class="info-btn listing-age-btn" title="View listing age details">📅 Listing age →</button>
        </div>
      </div>`;
    const imgEl = item.querySelector("img");
    if (imgEl) imgEl.addEventListener("error", () => { imgEl.style.display = "none"; });
    // "📅 Listing age" button inside salesRowsHtml → open listing age modal
    const analysisBtn = item.querySelector(".view-analysis-btn");
    if (analysisBtn) {
      analysisBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        openListingAgeModal(p.id);
      });
    }
    item.addEventListener("click", (event) => {
      if (event.target.closest(".info-btn")) {
        event.stopPropagation();
        if (event.target.closest(".list-btn")) openListing(p.id, p.name);
        else if (event.target.closest(".listing-age-btn")) openListingAgeModal(p.id);
        else openDetail(p.id);
        return;
      }
      if (p.productUrl) {
        chrome.tabs.create({ url: p.productUrl });
      } else if (p.id) {
        openDetail(p.id);
      }
    });
    resultsEl.appendChild(item);
  });
  // Show pagination if more than 1 page
  const paginationEl = document.getElementById("pagination");
  const prevBtn = document.getElementById("prevPage");
  const nextBtn = document.getElementById("nextPage");
  const pageInfo = document.getElementById("pageInfo");
  if (paginationEl && prevBtn && nextBtn && pageInfo) {
    if (totalPages > 1) {
      paginationEl.hidden = false;
      prevBtn.disabled = currentPage <= 1;
      nextBtn.disabled = currentPage >= totalPages;
      pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    } else {
      paginationEl.hidden = true;
    }
  }
}

function parseRange(value) {
  if (value === null || value === undefined || value === "") return null;
  const nums = (String(value).match(/\d+(\.\d+)?/g) || []).map(Number).filter(Number.isFinite);
  if (!nums.length) return null;
  return { min: Math.min(...nums), max: Math.max(...nums), display: String(value).trim() };
}

function stripHtml(value) {
  return String(value ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function stockByCountry(raw) {
  const map = {};
  const variants = Array.isArray(raw?.variants) ? raw.variants : [];
  variants.forEach((v) => {
    const invs = Array.isArray(v?.inventories) ? v.inventories : [];
    invs.forEach((inv) => {
      const code = inv?.countryCode || "?";
      map[code] = (map[code] || 0) + (Number(inv?.totalInventory) || 0);
    });
  });
  return Object.entries(map).filter(([, total]) => total > 0).sort((a, b) => b[1] - a[1]);
}

function stars(score) {
  if (score === null || score === undefined) return "";
  const n = Math.max(0, Math.min(5, Math.round(Number(score))));
  return "★".repeat(n) + "☆".repeat(5 - n);
}

function reviewsSectionHtml(reviews) {
  if (!reviews) {
    return `<div class="msection">Reviews</div>
      <div class="mrow"><span>Review count</span><strong>Unavailable (CJ call failed or rate-limited)</strong></div>`;
  }
  const recent = Array.isArray(reviews.recent) ? reviews.recent : [];
  const items = recent.map((r) => `
    <div class="review-item">
      <div class="review-top">
        <span class="review-stars">${stars(r.score)}</span>
        <span class="review-meta">${escapeHtml(r.user || "Buyer")}${r.country ? ` · ${escapeHtml(r.country)}` : ""}${r.date ? ` · ${escapeHtml(r.date)}` : ""}</span>
      </div>
      ${r.text ? `<p class="review-text">${escapeHtml(r.text)}</p>` : ""}
    </div>`).join("");
  return `
    <div class="msection">Reviews</div>
    <div class="mrow"><span>Total reviews</span><strong>${Number(reviews.total ?? 0).toLocaleString()}</strong></div>
    ${reviews.avgScoreRecent !== null && reviews.avgScoreRecent !== undefined
      ? `<div class="mrow"><span>Average (recent)</span><strong>${stars(reviews.avgScoreRecent)} ${escapeHtml(reviews.avgScoreRecent)}/5</strong></div>` : ""}
    ${reviews.last7d !== undefined && reviews.last7d !== null
      ? `<div class="mrow"><span>Reviews · last 7 days</span><strong>${escapeHtml(reviews.last7d)}</strong></div>` : ""}
    ${reviews.last30d !== undefined && reviews.last30d !== null
      ? `<div class="mrow"><span>Reviews · last 30 days</span><strong>${escapeHtml(reviews.last30d)}</strong></div>` : ""}
    ${items || `<div class="mrow"><span>Recent</span><strong>No reviews yet</strong></div>`}`;
}

function salesSectionHtml(metrics, sales) {
  const w30 = metrics?.windows?.d30 || null;
  const w7 = metrics?.windows?.d7 || null;
  const w90 = metrics?.windows?.d90 || null;
  const since = metrics?.trackingSince || "today";
  const sold90 = sales && Number.isFinite(Number(sales.sold90d)) ? Number(sales.sold90d) : null;
  const totalSales = sales && Number.isFinite(Number(sales.totalSales)) ? Number(sales.totalSales) : null;

  const windowEstimate = (win, days) => {
    if (win && Number(win.stockChange) > 0) return `~${Number(win.stockChange).toLocaleString()} (from stock drop)`;
    if (sold90 !== null) return `~${Math.max(0, Math.round((sold90 * days) / 90))} (from CJ 90-day sales)`;
    if (win) return "~0 (no net stock drop)";
    return `Collecting data (since ${since})`;
  };

  let totalText;
  if (totalSales !== null) {
    totalText = `${totalSales.toLocaleString()} CJ orders`;
    if (sales.lastOrderDate) totalText += ` · last ${sales.lastOrderDate}`;
  } else {
    totalText = "Not provided by CJ";
  }

  return `
    <div class="msection">Sales Count</div>
    <div class="mrow"><span>Total Sales</span><strong>${escapeHtml(totalText)}</strong></div>
    <div class="mrow"><span>Sales (Last 7 Days)</span><strong>${escapeHtml(windowEstimate(w7, 7))}</strong></div>
    <div class="mrow"><span>Sales (Last 30 Days)</span><strong>${escapeHtml(windowEstimate(w30, 30))}</strong></div>
    <div class="mrow"><span>Sales (Last 90 Days)</span><strong>${sold90 !== null ? `${sold90.toLocaleString()} (CJ actual)` : escapeHtml(windowEstimate(w90, 90))}</strong></div>
    <p class="mnote">Total Sales = CJ's real order count for this product (productDetail API). 7/30-day sales are estimated from CJ 90-day sales or daily stock snapshots this app records. 90-day sales are actual CJ data when available. Restocks can hide sales; signal, not proof.</p>`;
}

function sellingSitesHtml(p) {
  const sites = Array.isArray(p.sellingSites) ? p.sellingSites : [];
  if (!sites.length) return "";
  return `
    <div class="msection">Recommended Selling Site</div>
    ${sites.map((s) => `<div class="mrow mrow-sites"><span>🛍 ${escapeHtml(s.site)}</span><strong>${escapeHtml(s.why)}</strong></div>`).join("")}
    <p class="mnote">Category-based suggestion (heuristic, not a guarantee). CJ can push products and orders to Shopify, WooCommerce, eBay, Amazon and more via CJ → Integration.</p>`;
}

function detailHtml(p, reviews, metrics, sales, sup) {
  const raw = p.raw || {};
  const cost = parseRange(p.cjCostDisplay ?? raw.sellPrice);
  const suggest = parseRange(p.suggestSellPriceDisplay ?? raw.suggestSellPrice);
  let marginLine = "Not available";
  if (suggest && cost && suggest.min > cost.max) {
    const pct = (((suggest.min - cost.max) / suggest.min) * 100).toFixed(1);
    marginLine = `~${pct}% (suggested retail vs top variant cost)`;
  }
  const supplier = p.supplierName
    ? escapeHtml(p.supplierName) + (p.supplierId ? ` (id: ${escapeHtml(p.supplierId)})` : "")
    : "Not provided by CJ API (CJ-stocked product)";
  const sourceFrom = p.sourceFrom !== null && p.sourceFrom !== undefined ? String(p.sourceFrom) : "—";
  const countryStock = stockByCountry(raw);
  const description = stripHtml(raw.description).slice(0, 500);
  const weight = raw.productWeight ? `${escapeHtml(raw.productWeight)} g` : "—";
  const variants = Array.isArray(raw.variants) ? raw.variants.length : 0;

  return `
    ${p.image ? `<img class="modal-body-img" src="${escapeHtml(p.image)}" alt="">` : ""}
    <h3>${escapeHtml(p.name)}</h3>
    <div class="mrow"><span>SKU</span><strong>${escapeHtml(p.sku || raw.productSku || "—")}</strong></div>
    <div class="mrow"><span>CJ cost</span><strong>${cost ? escapeHtml(cost.display) : "—"}</strong></div>
    <div class="mrow"><span>CJ suggested retail</span><strong>${suggest ? escapeHtml(suggest.display) : "—"}</strong></div>
    <div class="mrow"><span>Suggested margin</span><strong>${marginLine}</strong></div>
    <div class="mrow"><span>Winning score</span><strong>${escapeHtml(p.score)}/100</strong></div>
    <div class="msection">Vendor / supplier</div>
    <div class="mrow"><span>Vendor name</span><strong>${supplier}</strong></div>
    <div class="mrow"><span>Source flag</span><strong>${escapeHtml(sourceFrom)}</strong></div>
    <div class="mrow"><span>Category</span><strong>${escapeHtml(p.category || raw.categoryName || "—")}</strong></div>
    ${raw.createrTime ? `<div class="mrow"><span>First listed on CJ</span><strong>${escapeHtml(String(raw.createrTime).slice(0, 10))}</strong></div>` : ""}
      ${raw.daysSinceListing !== null && raw.daysSinceListing !== undefined ? `<div class="mrow"><span>Days since first listed</span><strong>${Number(raw.daysSinceListing).toLocaleString()} day(s)${raw.daysSinceListing <= 7 ? " 🆕" : raw.daysSinceListing <= 30 ? " ✨" : ""}</strong></div>` : ""}
    <div class="mrow"><span>Website</span><strong>${sup?.website ? `<a class="mlink" href="${escapeHtml(/^https?:\/\//i.test(sup.website) ? sup.website : `https://${sup.website}`)}" target="_blank" rel="noopener">${escapeHtml(sup.website)}</a>` : "Not provided by CJ API"}</strong></div>
    <div class="mrow"><span>Email</span><strong>${sup?.email ? `<a class="mlink" href="mailto:${escapeHtml(sup.email)}">${escapeHtml(sup.email)}</a>` : "Not provided by CJ API"}</strong></div>
    <div class="mrow"><span>Phone</span><strong>${sup?.phone ? escapeHtml(sup.phone) : "Not provided by CJ API"}</strong></div>
    <div class="mrow"><span>US warehouse</span><strong>${sup?.hasUSWarehouse ? `✅ Yes — ${Number(sup.usInventory).toLocaleString()} in stock` : sup?.warehouseCountries && Object.keys(sup.warehouseCountries).length ? "No US stock" : "Not detected"}</strong></div>
    ${reviewsSectionHtml(reviews)}
    ${salesSectionHtml(metrics, sales)}
    ${sellingSitesHtml(p)}
    <div class="msection">Logistics</div>
    <div class="mrow"><span>Listed by sellers</span><strong>${p.listedNum ?? "—"}</strong></div>
    <div class="mrow"><span>Free shipping</span><strong>${p.isFreeShipping ? "Yes" : "No"}</strong></div>
    <div class="mrow"><span>Weight</span><strong>${weight}</strong></div>
    <div class="mrow"><span>Variants</span><strong>${variants}</strong></div>
    ${countryStock.length ? `<div class="msection">Stock by country</div>
      <div class="stock-chips">${countryStock.map(([c, n]) => `<span>${escapeHtml(c)}: ${n.toLocaleString()}</span>`).join("")}</div>` : ""}
    ${description ? `<div class="msection">Description</div><div class="mdesc">${escapeHtml(description)}…</div>` : ""}
    <div class="mactions">
      ${p.productUrl ? `<button type="button" id="modalOpenCj">Open on CJ</button>` : ""}
      <button type="button" id="modalListBtn" class="lp-btn-inline">🏪 List to CJ Store</button>
      <button type="button" id="modalCloseBtn" class="info-btn" style="flex:0 0 auto;padding:11px 14px">Close</button>
    </div>`;
}

function closeModal() {
  if (!modal) return;
  modal.hidden = true;
  modalBody.innerHTML = "";
}

async function openDetail(id) {
  if (!modal || !id) return;
  modal.hidden = false;
  modalBody.innerHTML = "<p class='message'>Loading product & supplier info…</p>";
  try {
    const res = await api(`/api/products/${encodeURIComponent(id)}`);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" "));
    modalBody.innerHTML = detailHtml(data.product, data.reviews, data.metrics, data.sales, data.supplier);
    const openCj = document.querySelector("#modalOpenCj");
    if (openCj && data.product?.productUrl) {
      openCj.addEventListener("click", () => chrome.tabs.create({ url: data.product.productUrl }));
    }
    const closeBtn = document.querySelector("#modalCloseBtn");
    if (closeBtn) closeBtn.addEventListener("click", closeModal);
    const listBtn = document.querySelector("#modalListBtn");
    if (listBtn) listBtn.addEventListener("click", () => {
      closeModal();
      openListing(data.product?.id || id, data.product?.name || "");
    });
  } catch (err) {
    modalBody.innerHTML = `<p class="error">${escapeHtml(err.message || "Request failed.")}</p>`;
  }
}

async function openListingAgeModal(id) {
  if (!id) return;
  modal.hidden = false;
  modalBody.innerHTML = "<p class='message'>Loading listing age…</p>";
  try {
    const res = await api(`/api/products/${encodeURIComponent(id)}`);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" "));
    const p = data.product;
    const sales = data.sales || {};
    const en = enrichMap[id] || {};
    const days = sales.daysSinceListing ?? en.daysSinceListing ?? null;
    const createrTime = sales.createrTime ?? en.createrTime ?? null;
    const name = p?.name || "Untitled product";

    let dateStr = "Unknown";
    if (createrTime) {
      const parsed = Number.isFinite(Number(createrTime)) ? Number(createrTime) : Date.parse(createrTime);
      if (Number.isFinite(parsed) && parsed > 0) dateStr = new Date(parsed).toISOString().slice(0, 10);
    }

    modalBody.innerHTML = `
      <h3 style="margin:0 36px 12px 0;font-size:15px;line-height:1.3">${escapeHtml(name)}</h3>
      <div class="msection">Listing Age</div>
      <div class="mrow"><span>First listed on CJ</span><strong>${escapeHtml(dateStr)}</strong></div>
      ${days !== null && days !== undefined ? `
        <div class="mrow"><span>Days since first listed</span><strong>${Number(days).toLocaleString()} day(s)</strong></div>
        <div class="mrow"><span>Months since listed</span><strong>${Math.floor(Number(days) / 30)} month(s)</strong></div>
        <div class="mrow"><span>Years since listed</span><strong>${Math.floor(Number(days) / 365)} year(s)</strong></div>
        ${Number(days) <= 7 ? `<div class="mrow"><span>Status</span><strong>🆕 New listing (≤7 days)</strong></div>` : ""}
        ${Number(days) <= 30 && Number(days) > 7 ? `<div class="mrow"><span>Status</span><strong>✨ New product (≤30 days)</strong></div>` : ""}
      ` : `<div class="mrow"><span>Days since first listed</span><strong>Not available from CJ API</strong></div>`}
      <div class="mactions">
        <button type="button" id="modalListBtn" class="lp-btn-inline">🏪 List to CJ Store</button>
        <button type="button" id="modalCloseBtn" class="button-secondary">Close</button>
      </div>`;
    const listBtn = document.querySelector("#modalListBtn");
    if (listBtn) listBtn.addEventListener("click", () => { closeModal(); openListing(id, name); });
    const closeBtn = document.querySelector("#modalCloseBtn");
    if (closeBtn) closeBtn.addEventListener("click", closeModal);
  } catch (err) {
    modalBody.innerHTML = `<p class="error">${escapeHtml(err.message || "Request failed.")}</p>`;
  }
}

if (modalClose) modalClose.addEventListener("click", closeModal);
if (modal) {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) closeModal();
  });
}

// ---------------- Variant Pricing / List to CJ store ----------------
const listingModal = document.querySelector("#listingModal");
const listingBody = document.querySelector("#listingBody");
const listingCloseBtn = document.querySelector("#listingClose");
const LISTING_COUNTRIES = ["US", "GB", "CA", "AU", "DE", "FR", "ES", "IT", "NL", "BE", "SE", "NO", "DK", "FI", "PL", "AT", "CH", "IE", "PT", "CZ", "GR", "RO", "HU", "MX", "BR", "CL", "JP", "KR", "SG", "MY", "TH", "PH", "ID", "VN", "NZ", "AE", "SA", "IN", "IL", "TR", "ZA"];
const LISTING_ORIGINS = [
  ["CN", "China (CN)"], ["US", "United States (US)"], ["TH", "Thailand (TH)"], ["DE", "Germany (DE)"],
  ["ES", "Spain (ES)"], ["GB", "United Kingdom (GB)"], ["FR", "France (FR)"], ["MY", "Malaysia (MY)"],
  ["VN", "Vietnam (VN)"], ["JP", "Japan (JP)"], ["KR", "South Korea (KR)"], ["HK", "Hong Kong (HK)"],
  ["TW", "Taiwan (TW)"], ["IN", "India (IN)"], ["AU", "Australia (AU)"], ["CA", "Canada (CA)"],
  ["NL", "Netherlands (NL)"], ["IT", "Italy (IT)"]
];
let listing = null;

function money(value) {
  const n = Number(value);
  return Number.isFinite(n) ? `$${n.toFixed(2)}` : "—";
}

function round2(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
}

function closeListing() {
  if (!listingModal) return;
  listingModal.hidden = true;
  listingBody.innerHTML = "";
  listing = null;
}

async function openListing(pid, fallbackTitle) {
  if (!listingModal || !pid) return;
  if (session && session.features && session.features.listing === false) {
    setMessage("Listing is turned off for your account. Contact support.", true);
    return;
  }
  listingModal.hidden = false;
  listingBody.innerHTML = "<p class='message'>Loading variant pricing from CJ…</p>";
  listing = null;
  try {
    const res = await api(`/api/listing/preview?pid=${encodeURIComponent(pid)}&country=US`);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" ") || "Preview failed.");
    listing = {
      pid,
      title: data.product?.title || fallbackTitle || pid,
      image: data.product?.image || null,
      store: data.store,
      country: data.shipping?.country || data.country || "US",
      margin: Number.isFinite(Number(data.margin)) ? Number(data.margin) : 0.3,
      methods: Array.isArray(data.shipping?.methods) ? data.shipping.methods : [],
      shipIdx: 0,
      shipping: Number(data.shipping?.price) || 0,
      shipName: data.shipping?.name || "",
      shipAging: data.shipping?.aging || "",
      from: data.shipFrom || "CN",
      shipNote: data.shipping?.note || "",
      quoted: Boolean(data.shipping?.quoted ?? data.shipping?.price),
      rows: (Array.isArray(data.variants) ? data.variants : []).map((v) => ({
        vid: v.vid,
        sku: v.sku || v.variantSku || "",
        color: v.color || "—",
        size: v.size || "—",
        image: v.image || "",
        cjPrice: Number(v.cjPrice) || 0,
        ship: data.shipping?.quoted ? Number(v.shipping) || 0 : null,
        total: Number(v.total) || 0,
        rrp: Number(v.rrp) || 0,
        price: Number.isFinite(Number(v.recommended)) ? Number(v.recommended) : 0,
        selected: true
      })),
      saving: false
    };
    renderListing();
  } catch (err) {
    listingBody.innerHTML = `<p class="error">${escapeHtml(err.message || "Could not load variant pricing.")}</p>
      <div class="mactions"><button type="button" id="lpCloseErr" class="lp-btn">Close</button></div>`;
    const btn = document.querySelector("#lpCloseErr");
    if (btn) btn.addEventListener("click", closeListing);
  }
}

function listingRecommended(row) {
  if (!listing) return 0;
  return round2((row.cjPrice + (Number(row.ship) || 0)) * (1 + listing.margin));
}

function listingCount() {
  return listing ? listing.rows.filter((r) => r.selected).length : 0;
}

function updateListingCount() {
  const el = document.querySelector("#lpSelected");
  if (el) el.textContent = `${listingCount()} variants selected`;
}

function recomputeTotals() {
  if (!listing) return;
  listing.rows.forEach((row) => {
    row.ship = listing.quoted ? listing.shipping : null;
    row.total = round2(row.cjPrice + (listing.quoted ? listing.shipping : 0));
    row.rrp = round2(row.cjPrice * (1 + listing.margin));
  });
}

function renderListing() {
  if (!listing) return;
  const { rows } = listing;
  const methodOptions = listing.methods.length
    ? listing.methods.map((m, i) => `<option value="${i}"${i === listing.shipIdx ? " selected" : ""}>${escapeHtml(m.name)} — ${money(m.price)}${m.aging ? ` (${escapeHtml(m.aging)})` : ""}</option>`).join("")
    : `<option value="">No route ${listing.from} → ${listing.country} — shipping not quoted</option>`;

  const body = rows.map((row) => `
    <tr data-vid="${escapeHtml(String(row.vid))}">
      <td><input type="checkbox" class="lp-check" ${row.selected ? "checked" : ""}></td>
      <td>${row.image ? `<img class="lp-thumb" src="${escapeHtml(row.image)}" alt="">` : "<span class='lp-noimg'>—</span>"}</td>
      <td class="lp-sku">${escapeHtml(row.sku)}</td>
      <td>${escapeHtml(row.color)}</td>
      <td>${escapeHtml(row.size)}</td>
      <td class="lp-rrp" title="Suggested retail = CJ price × (1 + margin)">${money(row.rrp)}</td>
      <td class="lp-cj">${money(row.cjPrice)}</td>
      <td class="lp-shipcost">${money(row.ship)}</td>
      <td class="lp-total">${money(row.total)}</td>
      <td><input type="number" class="lp-price" step="0.01" min="0" value="${row.price}"></td>
    </tr>`).join("");

  listingBody.innerHTML = `
    <div class="lp">
      <div class="lp-head">
        <div>
          <h3>Variant Pricing</h3>
          <small class="lp-product" title="${escapeHtml(listing.title)}">${escapeHtml(listing.title)}</small>
        </div>
        <span class="lp-store">🏪 ${escapeHtml(listing.store?.name || "CJ store")} <small>(${escapeHtml(listing.store?.type || "")})</small></span>
      </div>

      <div class="lp-tools">
        <span class="lp-tool">Bulk Revise:
          <select id="lpMode">
            <option value="set">Price Change</option>
            <option value="percent">Percent + %</option>
            <option value="add">Add $</option>
          </select>
          <input type="number" id="lpBulk" step="0.01" placeholder="e.g. 29.99" aria-label="Bulk value">
          <button type="button" class="lp-btn" id="lpBulkOk">OK</button>
        </span>
        <button type="button" class="lp-btn lp-btn-primary" id="lpRecommended">Recommended Listing Price ⓘ</button>
        <button type="button" class="lp-btn" id="lpAllOk">All OK</button>
        <span class="lp-tool">Margin <input type="number" id="lpMargin" step="1" min="0" max="500" value="${Math.round(listing.margin * 100)}">%</span>
        <span class="lp-tool">Ship From:
          <select id="lpFrom">${LISTING_ORIGINS.map(([code, label]) => `<option value="${code}"${code === listing.from ? " selected" : ""}>${label}</option>`).join("")}</select>
        </span>
        <span class="lp-tool">Deliver to:
          <select id="lpCountry">${LISTING_COUNTRIES.map((c) => `<option value="${c}"${c === listing.country ? " selected" : ""}>${c}</option>`).join("")}</select>
        </span>
        <span class="lp-count" id="lpSelected">0 variants selected</span>
      </div>

      <div class="lp-shipbar">
        <label>Shipping Cost:
          <select id="lpMethods">${methodOptions}</select>
        </label>
        <span class="lp-aging">${listing.shipAging ? `Est. delivery: ${escapeHtml(listing.shipAging)} days` : ""}</span>
        <small class="lp-note">${escapeHtml(listing.shipNote || `Shipping auto-calculated from ${listing.from} to ${listing.country} for the heaviest variant.`)} Applied to every row (CJ quotes per order).</small>
      </div>

      <div class="lp-wrap">
        <table class="lp-table">
          <thead>
            <tr>
              <th><input type="checkbox" id="lpAll" ${rows.every((r) => r.selected) ? "checked" : ""}></th>
              <th>Images</th><th>SKU</th><th>Color</th><th>Size</th>
              <th>RRP ⓘ</th><th>CJ Price</th><th>Shipping Cost</th><th>Total Dropshipping</th><th>* Your Price (USD)</th>
            </tr>
          </thead>
          <tbody>${body}</tbody>
        </table>
      </div>

      <div class="lp-status" id="lpStatus"></div>

      <div class="mactions lp-foot">
        <button type="button" class="lp-btn" id="lpCancel">Cancel</button>
        <button type="button" class="lp-btn lp-btn-primary" id="lpPublish">List It Now</button>
      </div>
    </div>`;

  wireListingEvents();
  updateListingCount();
}

function wireListingEvents() {
  const rowsEl = listingBody.querySelector(".lp-table tbody");
  const allEl = listingBody.querySelector("#lpAll");

  if (allEl) allEl.addEventListener("change", () => {
    listing.rows.forEach((r) => { r.selected = allEl.checked; });
    listingBody.querySelectorAll(".lp-check").forEach((cb) => { cb.checked = allEl.checked; });
    updateListingCount();
  });

  if (rowsEl) rowsEl.addEventListener("change", (event) => {
    const tr = event.target.closest("tr");
    if (!tr) return;
    const row = listing.rows.find((r) => String(r.vid) === tr.dataset.vid);
    if (!row) return;
    if (event.target.classList.contains("lp-check")) {
      row.selected = event.target.checked;
      updateListingCount();
    }
    if (event.target.classList.contains("lp-price")) {
      row.price = round2(event.target.value);
      event.target.value = row.price;
    }
  });

  const recommendedBtn = listingBody.querySelector("#lpRecommended");
  if (recommendedBtn) recommendedBtn.addEventListener("click", () => {
    listing.rows.filter((r) => r.selected).forEach((r) => { r.price = listingRecommended(r); });
    syncPricesToInputs();
    setListingStatus(`Recommended prices applied to ${listingCount()} variant(s).`);
  });

  const allOkBtn = listingBody.querySelector("#lpAllOk");
  if (allOkBtn) allOkBtn.addEventListener("click", () => {
    listing.rows.forEach((r) => { r.selected = true; if (!r.price) r.price = listingRecommended(r); });
    listingBody.querySelectorAll(".lp-check").forEach((cb) => { cb.checked = true; });
    const all = listingBody.querySelector("#lpAll");
    if (all) all.checked = true;
    syncPricesToInputs();
    updateListingCount();
    setListingStatus("All variants selected and priced.");
  });

  const bulkOk = listingBody.querySelector("#lpBulkOk");
  if (bulkOk) bulkOk.addEventListener("click", () => {
    const mode = listingBody.querySelector("#lpMode").value;
    const value = Number(listingBody.querySelector("#lpBulk").value);
    if (!Number.isFinite(value)) { setListingStatus("Enter a value for Bulk Revise first.", true); return; }
    const selected = listing.rows.filter((r) => r.selected);
    if (!selected.length) { setListingStatus("Select at least one variant.", true); return; }
    selected.forEach((r) => {
      if (mode === "set") r.price = round2(value);
      else if (mode === "percent") r.price = round2(r.total * (1 + value / 100));
      else r.price = round2(r.total + value);
    });
    syncPricesToInputs();
    setListingStatus(`Bulk revise applied to ${selected.length} variant(s).`);
  });

  const marginEl = listingBody.querySelector("#lpMargin");
  if (marginEl) marginEl.addEventListener("change", () => {
    const prevMargin = listing.margin;
    const oldRec = listing.rows.map((r) => round2((r.cjPrice + (Number(r.ship) || 0)) * (1 + prevMargin)));
    const pct = Number(marginEl.value);
    listing.margin = Number.isFinite(pct) && pct >= 0 ? pct / 100 : 0.3;
    listing.rows.forEach((r, i) => { if (Number(r.price) && Number(r.price) === oldRec[i]) r.price = listingRecommended(r); });
    recomputeTotals();
    refreshTotalsDom();
    syncPricesToInputs();
  });

  const methodsEl = listingBody.querySelector("#lpMethods");
  if (methodsEl) methodsEl.addEventListener("change", () => {
    const oldRec = listing.rows.map((r) => round2((r.cjPrice + (Number(r.ship) || 0)) * (1 + listing.margin)));
    const idx = Number(methodsEl.value);
    const method = listing.methods[idx];
    if (!method) return;
    listing.shipIdx = idx;
    listing.shipping = Number(method.price) || 0;
    listing.shipName = method.name;
    listing.shipAging = method.aging || "";
    listing.rows.forEach((r, i) => { if (Number(r.price) && Number(r.price) === oldRec[i]) r.price = listingRecommended(r); });
    recomputeTotals();
    refreshTotalsDom();
    syncPricesToInputs();
    const aging = listingBody.querySelector(".lp-aging");
    if (aging) aging.textContent = listing.shipAging ? `Est. delivery: ${listing.shipAging} days` : "";
  });

  const countryEl = listingBody.querySelector("#lpCountry");
  if (countryEl) countryEl.addEventListener("change", () => reloadListing(countryEl.value, listing.from));
  const fromEl = listingBody.querySelector("#lpFrom");
  if (fromEl) fromEl.addEventListener("change", () => reloadListing(listing.country, fromEl.value));

  const publishBtn = listingBody.querySelector("#lpPublish");
  if (publishBtn) publishBtn.addEventListener("click", publishListing);

  const cancelBtn = listingBody.querySelector("#lpCancel");
  if (cancelBtn) cancelBtn.addEventListener("click", closeListing);
}

function setListingStatus(text, isError) {
  const el = listingBody.querySelector("#lpStatus");
  if (!el) return;
  el.classList.toggle("is-error", Boolean(isError));
  el.textContent = text || "";
}

function syncPricesToInputs() {
  listingBody.querySelectorAll("tr[data-vid]").forEach((tr) => {
    const row = listing.rows.find((r) => String(r.vid) === tr.dataset.vid);
    if (!row) return;
    const input = tr.querySelector(".lp-price");
    if (input) input.value = row.price;
  });
}

function refreshTotalsDom() {
  listingBody.querySelectorAll("tr[data-vid]").forEach((tr) => {
    const row = listing.rows.find((r) => String(r.vid) === tr.dataset.vid);
    if (!row) return;
    const rrp = tr.querySelector(".lp-rrp");
    const ship = tr.querySelector(".lp-shipcost");
    const total = tr.querySelector(".lp-total");
    if (rrp) rrp.textContent = money(row.rrp);
    if (ship) ship.textContent = money(row.ship);
    if (total) total.textContent = money(row.total);
  });
  setListingStatus(`Totals updated for ${listing.country} · margin ${Math.round(listing.margin * 100)}%.`);
}

async function reloadListing(country, from = listing.from) {
  const { pid, rows } = listing;
  const prices = Object.fromEntries(rows.map((r) => [String(r.vid), r.price]));
  const oldRows = new Map(rows.map((r) => [String(r.vid), r]));
  const oldMargin = listing.margin;
  const selected = rows.filter((r) => r.selected).map((r) => String(r.vid));
  const title = listing.title;
  try {
    const res = await api(`/api/listing/preview?pid=${encodeURIComponent(pid)}&country=${encodeURIComponent(country)}&from=${encodeURIComponent(from)}&margin=${encodeURIComponent(listing.margin)}`);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" ") || "Preview failed.");
    listing = {
      pid, title,
      image: data.product?.image || listing.image,
      store: data.store,
      country,
      margin: Number.isFinite(Number(data.margin)) ? Number(data.margin) : listing.margin,
      methods: Array.isArray(data.shipping?.methods) ? data.shipping.methods : [],
      shipIdx: 0,
      shipping: Number(data.shipping?.price) || 0,
      shipName: data.shipping?.name || "",
      shipAging: data.shipping?.aging || "",
      from: data.shipFrom || "CN",
      shipNote: data.shipping?.note || "",
      quoted: Boolean(data.shipping?.quoted ?? data.shipping?.price),
      rows: (Array.isArray(data.variants) ? data.variants : []).map((v) => ({
        vid: v.vid,
        sku: v.sku || v.variantSku || "",
        color: v.color || "—",
        size: v.size || "—",
        image: v.image || "",
        cjPrice: Number(v.cjPrice) || 0,
        ship: data.shipping?.quoted ? Number(v.shipping) || 0 : null,
        total: Number(v.total) || 0,
        rrp: Number(v.rrp) || 0,
        price: (() => {
          const rec = Number.isFinite(Number(v.recommended)) ? Number(v.recommended) : 0;
          const prev = prices[String(v.vid)];
          if (prev === undefined) return rec;
          const prevNum = Number(prev);
          const old = oldRows.get(String(v.vid));
          if (!prevNum || !old) return prevNum;
          const oldRec = round2((old.cjPrice + (Number(old.ship) || 0)) * (1 + oldMargin));
          return prevNum === oldRec ? rec : prevNum;
        })(),
        selected: selected.includes(String(v.vid))
      })),
      saving: false
    };
    renderListing();
    setListingStatus(`Shipping re-quoted: ${from} → ${country}.`);
  } catch (err) {
    setListingStatus(err.message || "Country re-quote failed.", true);
    const countryEl = listingBody.querySelector("#lpCountry");
    if (countryEl) countryEl.value = listing.country;
  }
}

async function publishListing() {
  if (!listing || listing.saving) return;
  const selectedRows = listing.rows.filter((r) => r.selected);
  if (!selectedRows.length) { setListingStatus("Select at least one variant to list.", true); return; }
  if (!listing.quoted) {
    setListingStatus(`No shipping route from ${listing.from} to ${listing.country} for this product — totals would exclude shipping. Choose another Ship From / Deliver to first.`, true);
    return;
  }
  const missing = selectedRows.filter((r) => !Number.isFinite(Number(r.price)) || Number(r.price) <= 0);
  if (missing.length) { setListingStatus(`Enter "Your Price" for ${missing.length} variant(s) (use Recommended Listing Price).`, true); return; }

  listing.saving = true;
  const publishBtn = listingBody.querySelector("#lpPublish");
  const cancelBtn = listingBody.querySelector("#lpCancel");
  if (publishBtn) { publishBtn.disabled = true; publishBtn.textContent = "Listing…"; }
  if (cancelBtn) cancelBtn.disabled = true;
  setListingStatus(`Listing ${selectedRows.length} variant(s) to ${listing.store?.name || "CJ store"}…`);

  try {
    const res = await api("/api/listing/publish", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        pid: listing.pid,
        country: listing.country,
        from: listing.from,
        logistics: listing.shipName,
        title: listing.title,
        selected: selectedRows.map((r) => String(r.vid)),
        prices: Object.fromEntries(listing.rows.map((r) => [String(r.vid), Number(r.price) || 0]))
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" ") || "Listing failed.");
    if (data.ok === false && !data.variantsSaved && !data.existingVariants) throw new Error((Array.isArray(data.warnings) && data.warnings[0]) || "CJ did not save this product.");
    renderListingDone(data);
  } catch (err) {
    listing.saving = false;
    if (publishBtn) { publishBtn.disabled = false; publishBtn.textContent = "List It Now"; }
    if (cancelBtn) cancelBtn.disabled = false;
    setListingStatus(err.message || "Could not list the product.", true);
  }
}

function renderListingDone(data) {
  const warnings = Array.isArray(data.warnings) && data.warnings.length
    ? `<div class="lp-warn">${data.warnings.map((w) => `<div>⚠ ${escapeHtml(w)}</div>`).join("")}</div>`
    : "";
  listingBody.innerHTML = `
    <div class="lp lp-done">
      <div class="lp-head">
        <div>
          <h3>✅ Listed to ${escapeHtml(data.store?.name || "your CJ store")}</h3>
          <small class="lp-product">${escapeHtml(data.title || listing.title || "")}</small>
        </div>
      </div>
      <div class="mrow"><span>Store product ID</span><strong>${escapeHtml(data.storeProductId || "—")}</strong></div>
      <div class="mrow"><span>Product record</span><strong>${data.productExisted ? "Existing (already listed)" : "Created"}</strong></div>
      <div class="mrow"><span>Variants saved</span><strong>${escapeHtml(String(data.variantsSaved ?? 0))} / ${escapeHtml(String(data.variantsRequested ?? 0))}</strong></div>
      <div class="mrow"><span>Already in store (price unchanged)</span><strong>${escapeHtml(String(data.existingVariants ?? 0))}</strong></div>
      <div class="mrow"><span>Shipping method</span><strong>${escapeHtml(data.logistics || listing.shipName || "—")}</strong></div>
      <div class="mrow"><span>Product connection</span><strong>${data.connected ? "Created" : "Skipped"}</strong></div>
      ${warnings}
      <div class="mactions lp-foot">
        <a class="lp-btn" href="https://cjdropshipping.com/mycj" target="_blank" rel="noopener">Open My CJ</a>
        <button type="button" class="lp-btn lp-btn-primary" id="lpDone">Close</button>
      </div>
    </div>`;
  const done = listingBody.querySelector("#lpDone");
  if (done) done.addEventListener("click", closeListing);
}

if (listingCloseBtn) listingCloseBtn.addEventListener("click", closeListing);
if (listingModal) {
  listingModal.addEventListener("click", (event) => {
    if (event.target === listingModal) closeListing();
  });
}
document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (listingModal && !listingModal.hidden) closeListing();
  else if (modal && !modal.hidden) closeModal();
});

function finalizeBestSelling() {
  const hasAnySales = shownProducts.some((p) => {
    const av = enrichMap[p.id]?.totalSales;
    return av !== null && av !== undefined && Number.isFinite(Number(av)) && Number(av) > 0;
  });
  shownProducts = [...shownProducts].sort((a, b) => {
    const av = enrichMap[a.id]?.totalSales;
    const bv = enrichMap[b.id]?.totalSales;
    const an = av !== null && av !== undefined && Number.isFinite(Number(av)) ? Number(av) : null;
    const bn = bv !== null && bv !== undefined && Number.isFinite(Number(bv)) ? Number(bv) : null;
    if (an !== null && bn !== null) return bn - an;
    if (an !== null) return -1;
    if (bn !== null) return 1;
    // Fallback: sort by listedNum (CJ listing count = demand signal)
    const la = Number(a.listedNum) || 0;
    const lb = Number(b.listedNum) || 0;
    return lb - la;
  });
  renderProducts(shownProducts);
  const note = hasAnySales
    ? "sorted by CJ total orders"
    : "CJ sales data unavailable — sorted by listing count instead";
  setMessage(`Best-selling view: ${shownProducts.length} product(s) ${note}. Estimates are daily/monthly sales signals.`, false);
}

async function enrichShown(gen, isBestSelling, products, { filterFirst = false } = {}) {
  const base = products || shownProducts;
  const ids = base.map((p) => p.id).filter(Boolean).filter((id) => !enrichMap[id]);
  const finish = () => {
    if (gen !== searchGen) return;
    const filtered = applyRangeFilters(applyListingFilters(base));
    renderProducts(filtered);
    if (isBestSelling) {
      finalizeBestSelling();
      if (filterFirst) setMessage(`Best-selling + listing filters: ${shownProducts.length} of ${base.length} product(s).`, false);
      return;
    }
    if (filterFirst) {
      setMessage(filtered.length
        ? `${filtered.length} of ${base.length} product(s) match the listing-age filters (CJ age data loaded).`
        : `0 of ${base.length} product(s) match. Loosen filters or try trending mode.`, false);
    } else if (ids.length) {
      setMessage(`${filtered.length} product(s) · sales, ratings & estimates loaded.`, false);
    }
  };
  if (!ids.length) {
    finish();
    return;
  }
  ids.forEach((id) => pendingEnrich.add(id));
  if (gen === searchGen) {
    if (filterFirst) setMessage(`Checking CJ listing age…0/${base.length}`, false);
    else renderProducts(applyRangeFilters(applyListingFilters(base)));
  }
  for (let i = 0; i < ids.length; i += 3) {
    const chunk = ids.slice(i, i + 3);
    try {
      const res = await api(`/api/enrich?ids=${chunk.map(encodeURIComponent).join(",")}`);
      const data = await res.json();
      if (res.ok && data.items) Object.assign(enrichMap, data.items);
    } catch {
      // enrich is optional; cards keep base data
    }
    chunk.forEach((id) => pendingEnrich.delete(id));
    if (gen !== searchGen) return;
    if (filterFirst) {
      const filtered = applyRangeFilters(applyListingFilters(base));
      renderProducts(filtered);
      const checked = base.length - (ids.length - i - chunk.length);
      setMessage(`Checking CJ listing age… ${checked}/${base.length} checked · ${filtered.length} match so far`, false);
    } else {
      renderProducts(applyRangeFilters(applyListingFilters(base)));
    }
  }
  finish();
}

async function runSearch({ trending = false, bestSelling = false } = {}) {
  lastSearchParams = { trending, bestSelling };
  currentPage = 1;
  totalPages = 1;
  searchButton.disabled = true;
  trendingButton.disabled = true;
  if (bestSellingButton) bestSellingButton.disabled = true;
  if (bestSellerSupplierButton) bestSellerSupplierButton.disabled = true;
  searchButton.textContent = "Hunting…";
  const gen = ++searchGen;
  bestSellingMode = bestSelling;
  pendingEnrich = new Set();
  setMessage(
    bestSelling
      ? "Best-selling hunt: loading CJ products, then counting real orders…"
      : trending
        ? "Loading CJ trending winning products…"
        : "Requesting product data from CJ via local backend…",
    false
  );
  resultsEl.innerHTML = "";
  try {
    const useTrending = trending || (bestSelling && !queryInput.value.trim());
    const params = buildParams(useTrending ? { trending: "1", q: "" } : {});
    const res = await api(`/api/products?${params}`);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" "));
    const products = data.products || [];
    totalPages = Number(data.totalPages) || 1;
    if (!products.length) {
      setMessage("No products matched. Loosen the filters or try another keyword.", false);
      setStatus("Backend ready · 0 products", "warn");
      return;
    }
    setStatus("Backend ready · CJ data loaded", "ok");
    try {
      await chrome.storage.local.set({ lastQuery: queryInput.value.trim() });
    } catch {
      /* local storage is optional */
    }
    shownProducts = products;
    const lf = readListingFilters();
    const needsMeta = lf.newListing || lf.newProduct || lf.reListing;
    if (needsMeta) {
      renderProducts([]);
      setMessage(`Checking CJ listing age…0/${products.length}`, false);
      enrichShown(gen, bestSelling, products, { filterFirst: true });
    } else {
      const filtered = applyRangeFilters(applyListingFilters(products));
      renderProducts(filtered);
      if (lf.neverListed && !filtered.length) {
        setMessage("0 products match 'never listed' (listedNum = 0) on this page. Try another page or trending mode.", false);
      }
      enrichShown(gen, bestSelling, filtered);
    }
  } catch (err) {
    const text = err.message || "Request failed.";
    if (/Failed to fetch|NetworkError|load failed/i.test(text)) {
      setStatus("Server not reachable", "error");
      setMessage("Could not reach the CJ Product Hunter server. Check your internet connection and try again.", true);
    } else if (/API key not configured/i.test(text)) {
      setStatus("CJ API key needed", "warn");
      setMessage("Paste your CJdropshipping API key (⚙ Key) to start hunting.", true);
      openSettings();
    } else {
      setStatus("Search failed", "error");
      setMessage(text, true);
    }
  } finally {
    searchButton.disabled = false;
    trendingButton.disabled = false;
    if (bestSellingButton) bestSellingButton.disabled = false;
    if (bestSellerSupplierButton) bestSellerSupplierButton.disabled = false;
    searchButton.textContent = "Hunt";
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  runSearch();
});

trendingButton.addEventListener("click", () => {
  runSearch({ trending: true });
});

if (bestSellingButton) {
  bestSellingButton.addEventListener("click", () => {
    runSearch({ bestSelling: true });
  });
}

if (bestSellerSupplierButton) {
  bestSellerSupplierButton.addEventListener("click", () => {
    // Show country filter when best sellers mode is active
    if (countryFilterBar) countryFilterBar.hidden = false;
    runBestSellerSupplierSearch();
  });
}

// Hide country filter bar when regular search / trending / best-selling mode
if (searchButton) {
  searchButton.addEventListener("click", () => {
    if (countryFilterBar) countryFilterBar.hidden = true;
  });
}
if (trendingButton) {
  trendingButton.addEventListener("click", () => {
    if (countryFilterBar) countryFilterBar.hidden = true;
  });
}
if (bestSellingButton) {
  bestSellingButton.addEventListener("click", () => {
    if (countryFilterBar) countryFilterBar.hidden = true;
  });
}

// Pagination: load a different page with the same search params
function loadPage(page) {
  if (page < 1 || page > totalPages || page === currentPage) return;
  currentPage = page;
  runSearch(lastSearchParams);
}
const prevPageBtn = document.getElementById("prevPage");
const nextPageBtn = document.getElementById("nextPage");
if (prevPageBtn) prevPageBtn.addEventListener("click", () => loadPage(currentPage - 1));
if (nextPageBtn) nextPageBtn.addEventListener("click", () => loadPage(currentPage + 1));

async function runBestSellerSupplierSearch() {
  const query = queryInput.value.trim();
  if (!query) {
    setMessage("Type a product keyword first, then click 🏆 Best Sellers.", true);
    return;
  }
  searchButton.disabled = true;
  trendingButton.disabled = true;
  if (bestSellingButton) bestSellingButton.disabled = true;
  if (bestSellerSupplierButton) bestSellerSupplierButton.disabled = true;
  searchButton.textContent = "Hunting…";
  resultsEl.innerHTML = "";
  setMessage(`🏆 Searching best-selling suppliers for "${query}"…`, false);
  try {
    const countryFilter = bestSellerCountrySelect ? bestSellerCountrySelect.value : "";
    const url = countryFilter
      ? `/api/suppliers/best-sellers?sortBy=90d&q=${encodeURIComponent(query)}&pageSize=50&country=${encodeURIComponent(countryFilter)}`
      : `/api/suppliers/best-sellers?sortBy=90d&q=${encodeURIComponent(query)}&pageSize=50`;
    const res = await api(url);
    const data = await res.json();
    if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" "));
    const suppliers = data.suppliers || [];
    const hasSales = suppliers.some(s => (s.sold90d || 0) > 0 || (s.totalSales || 0) > 0);
    const filterNote = data.filterNote || "";
    const filterCountry = data.filterCountry || "";
    if (!suppliers.length) {
      if (filterNote) {
        setStatus(filterNote, "warn");
        setMessage(filterNote, true);
      } else {
        setMessage("No suppliers found for this keyword.", false);
        setStatus("Backend ready · 0 suppliers", "warn");
      }
      return;
    }
    const salesNote = hasSales
      ? ""
      : " · (CJ sales data unavailable — sorted by listing count instead)";
    const countryLabel = filterCountry ? ` · Shipping to: ${filterCountry}` : "";
    setStatus(`Backend ready · ${suppliers.length} suppliers found${salesNote}${countryLabel}`, "ok");
    renderSupplierBestSellers(suppliers, data.sortBy, data.searchQuery, hasSales, filterCountry, filterNote);
  } catch (err) {
    const text = err.message || "Request failed.";
    if (/Failed to fetch|NetworkError/i.test(text)) {
      setStatus("Server not reachable", "error");
      setMessage("Could not reach the server. Check your internet.", true);
    } else if (/504|timed out|FUNCTION_INVOCATION_TIMEOUT/i.test(text)) {
      setStatus("Request timed out", "error");
      setMessage("The CJ API is slow right now — too many products to fetch. Try a narrower keyword, or click 🏆 Best Sellers again in a minute.", true);
    } else if (/502|CJ returned|API key/i.test(text)) {
      setStatus("CJ API error", "error");
      setMessage("CJ API returned an error. This usually means your API key is invalid or you've hit the rate limit. Try again in a few minutes, or re-enter your CJ API key (⚙ Key).", true);
    } else {
      setStatus("Search failed", "error");
      setMessage(text, true);
    }
  } finally {
    searchButton.disabled = false;
    trendingButton.disabled = false;
    if (bestSellingButton) bestSellingButton.disabled = false;
    if (bestSellerSupplierButton) bestSellerSupplierButton.disabled = false;
    searchButton.textContent = "Hunt";
  }
}

function renderSupplierBestSellers(suppliers, sortBy, searchQuery, hasSales, filterCountry, filterNote) {
  const sortLabels = { "7d": "7 days", "30d": "30 days", "90d": "90 days" };
  const container = document.createElement("div");
  container.className = "supplier-results";

  // ── Header / summary ──
  const countryNote = filterCountry ? ` · Ship to: ${filterCountry}` : "";
  const filterNoteHtml = filterNote
    ? `<div class="supplier-filter-note">⚠️ ${escHtml(filterNote)}</div>`
    : "";
  container.innerHTML = `
    <div class="supplier-summary">
      <strong>🏆 Best-Selling Suppliers</strong>
      <span class="supplier-meta">Sorted by CJ total orders (orderCount) · Query: "${escHtml(searchQuery)}" · ${suppliers.length} supplier(s)${hasSales ? "" : " · CJ sales data unavailable — sorted by listing count"}${countryNote}</span>
    </div>
    <div class="supplier-legend">
      <span class="stat-badge stat-7d">7d sales</span>
      <span class="stat-badge stat-30d">30d sales</span>
      <span class="stat-badge stat-90d">90d sales</span>
      <span class="stat-badge stat-total">Total orders</span>
      <span class="stat-badge" style="background:#e0e7ff;color:#3730a3">📦 Warehouses</span>
    </div>
    ${filterNoteHtml}
  `;

  suppliers.forEach((sup, idx) => {
    const card = document.createElement("div");
    card.className = "supplier-card";
    card.innerHTML = `
      <div class="supplier-rank">#${idx + 1}</div>
      <div class="supplier-info">
        <div class="supplier-name">${escHtml(sup.supplierName)}</div>
        ${sup.supplierId ? `<div class="supplier-id">Supplier ID: ${escHtml(sup.supplierId)}</div>` : ""}
        <div class="supplier-stats">
          <span class="stat-badge stat-7d">7d: ${Number(sup.sold7d || 0).toLocaleString()}</span>
          <span class="stat-badge stat-30d">30d: ${Number(sup.sold30d || 0).toLocaleString()}</span>
          <span class="stat-badge stat-90d">90d: ${Number(sup.sold90d || 0).toLocaleString()}</span>
          <span class="stat-badge stat-total">Total: ${Number(sup.totalSales || 0).toLocaleString()}</span>
          ${!hasSales && sup.listedNum ? `<span class="stat-badge" style="background:#f5f5f5;color:#666">Listed: ${Number(sup.listedNum).toLocaleString()}</span>` : ""}
        </div>
        <div class="supplier-products-count">${sup.products.length} product(s) listed</div>
        ${sup.warehouseCountries && sup.warehouseCountries.length ? `
          <div class="supplier-warehouses">
            <span class="wh-label">📦 Ships from:</span>
            ${sup.warehouseCountries.slice(0, 8).map(w =>
              `<span class="wh-tag" title="${w.qty} units in ${w.code}">${w.code} (${Number(w.qty).toLocaleString()})</span>`
            ).join("")}
            ${sup.warehouseCountries.length > 8
              ? `<span class="wh-more">+${sup.warehouseCountries.length - 8} more</span>`
              : ""}
          </div>
        ` : ""}
      </div>
      <div class="supplier-expand">▸ View details</div>
    `;
    container.appendChild(card);

    // ── Expandable detail panel ──
    const detail = document.createElement("div");
    detail.className = "supplier-detail hidden";
    detail.id = `supplier-detail-${idx}`;

    // Top products by sales
    const topProducts = sup.topProducts && sup.topProducts.length
      ? sup.topProducts
      : sup.products
          .filter((p) => p.sales && Number(p.sales.totalSales) > 0)
          .sort((a, b) => Number(b.sales?.totalSales || 0) - Number(a.sales?.totalSales || 0))
          .slice(0, 5)
          .map((p) => ({
            id: p.id,
            name: p.name,
            image: p.image,
            cjCost: p.cjCost,
            currency: p.currency,
            totalSales: Number(p.sales?.totalSales) || 0,
            sold7d: Number(p.sales?.sold7d) || 0,
            sold30d: Number(p.sales?.sold30d) || 0,
            sold90d: Number(p.sales?.sold90d) || 0,
            listedNum: Number(p.listedNum) || 0,
            daysSinceListing: p.sales?.daysSinceListing ?? null,
            createrTime: p.sales?.createrTime ?? null,
            supplierName: p.supplierName,
            supplierId: p.supplierId
          }));

    if (topProducts.length) {
      const topHeader = document.createElement("div");
      topHeader.className = "supplier-detail-header";
      topHeader.textContent = `🔥 Top ${topProducts.length} selling product(s)`;
      detail.appendChild(topHeader);

      topProducts.forEach((tp) => {
        const row = document.createElement("div");
        row.className = "supplier-product-row";
        row.innerHTML = `
          <img src="${tp.image || ""}" alt="" class="supplier-product-img" onerror="this.style.display='none'">
          <div class="supplier-product-info">
            <div class="supplier-product-name">${escHtml(tp.name || "Untitled")}</div>
            <div class="supplier-product-meta">
              <span>CJ cost: ${tp.currency || "USD"} ${Number(tp.cjCost || 0).toFixed(2)}</span>
              <span>· 🏪 Listed by ${Number(tp.listedNum || 0).toLocaleString()} sellers</span>
              ${tp.daysSinceListing !== null && tp.daysSinceListing !== undefined
                ? `<span>· 📅 ${formatListingAge(tp.daysSinceListing, tp.createrTime)}</span>`
                : ""}
            </div>
          </div>
          <div class="supplier-product-sales">
            <span class="stat-badge stat-7d">${Number(tp.sold7d || 0).toLocaleString()}</span>
            <span class="stat-badge stat-30d">${Number(tp.sold30d || 0).toLocaleString()}</span>
            <span class="stat-badge stat-90d">${Number(tp.sold90d || 0).toLocaleString()}</span>
            <span class="stat-badge stat-total">${Number(tp.totalSales || 0).toLocaleString()}</span>
          </div>
        `;
        row.addEventListener("click", () => {
          if (tp.id) openDetail(tp.id);
        });
        detail.appendChild(row);
      });
    } else {
      const empty = document.createElement("div");
      empty.className = "supplier-detail-empty";
      empty.textContent = "No sales data available for individual products.";
      detail.appendChild(empty);
    }

    card.addEventListener("click", () => {
      detail.classList.toggle("hidden");
      card.querySelector(".supplier-expand").textContent = detail.classList.contains("hidden")
        ? "▸ View details"
        : "▾ Hide details";
    });
    container.appendChild(detail);
  });

  resultsEl.appendChild(container);
}

function escHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

if (resetFiltersButton) {
  resetFiltersButton.addEventListener("click", () => {
    ["#fMinPrice", "#fMaxPrice", "#fMinStock", "#fMaxStock", "#fMinListed", "#fMaxListed"].forEach((id) => {
      const el = document.querySelector(id);
      if (el) el.value = "";
    });
    const country = document.querySelector("#fCountry");
    if (country) country.value = "";
    const freeShip = document.querySelector("#fFreeShip");
    if (freeShip) freeShip.checked = false;
    ["#fNewListing", "#fNewProduct", "#fRelisting", "#fNeverListed"].forEach((id) => {
      const el = document.querySelector(id);
      if (el) el.checked = false;
    });
    setMessage("Filters reset.", false);
  });
}

const isWindowMode = new URLSearchParams(window.location.search).get("mode") === "window";
const openWindowButton = document.querySelector("#openWindow");
if (openWindowButton) {
  if (isWindowMode) {
    openWindowButton.style.display = "none";
  } else {
    openWindowButton.addEventListener("click", () => {
      chrome.windows.create({
        url: chrome.runtime.getURL("sidepanel.html?mode=window"),
        type: "popup",
        width: 560,
        height: 840
      });
    });
  }
}

async function init() {
  setStatus("Checking your account…", "warn");

  // Optional one-off backend override. Only honoured for a real https URL —
  // a stale localhost value in storage would break the extension ("Failed to fetch").
  try {
    const { apiBase } = await chrome.storage.local.get(["apiBase"]);
    if (apiBase) {
      const candidate = String(apiBase).replace(/\/+$/, "");
      if (/^https:\/\//i.test(candidate)) {
        API_BASE = candidate;
      }
    }
  } catch {
    /* storage unavailable */
  }

  // Always ensure we connect to the live backend, not localhost.
  API_BASE = DEFAULT_API_BASE;

  let saved = {};
  try {
    saved = await chrome.storage.local.get([TOKEN_STORAGE_KEY, "lastQuery"]);
  } catch {
    saved = {};
  }
  token = saved[TOKEN_STORAGE_KEY] || "";
  if (saved.lastQuery && queryInput && !queryInput.value) queryInput.value = saved.lastQuery;

  if (!token) {
    showAuth();
    return;
  }

  const me = await fetchMe();
  if (me) {
    enterApp(me);
  } else {
    showAuth();
  }
}

init();

// ── CJ API key (one-time setup per account) ──────────────────────
const settingsModal = document.querySelector("#settingsModal");
const settingsBtn = document.querySelector("#settingsBtn");
const cjKeyInput = document.querySelector("#cjKeyInput");
const cjKeyMeta = document.querySelector("#cjKeyMeta");
const cjKeyStatus = document.querySelector("#cjKeyStatus");
const cjKeySaveBtn = document.querySelector("#cjKeySave");
const cjKeyRemoveBtn = document.querySelector("#cjKeyRemove");
const cjKeyToggleBtn = document.querySelector("#cjKeyToggle");
const settingsCloseBtn = document.querySelector("#settingsClose");

function setSettingsStatus(text, isError) {
  if (!cjKeyStatus) return;
  cjKeyStatus.textContent = text || "";
  cjKeyStatus.classList.toggle("error", Boolean(isError));
  cjKeyStatus.classList.toggle("is-error", Boolean(isError));
}

function markKeyMeta(text, state) {
  if (!cjKeyMeta) return;
  cjKeyMeta.textContent = text;
  cjKeyMeta.classList.remove("is-warn", "is-ok");
  if (state) cjKeyMeta.classList.add(state);
}

async function refreshStatus() {
  if (!statusEl) return;
  if (session && session.isBlocked) return;
  try {
    const res = await api("/api/keys");
    const data = await res.json().catch(() => ({}));
    if (data.exists) setStatus(`Ready · CJ key connected${usageSummary()}`, "ok");
    else setStatus("Add your CJ API key", "warn");
  } catch {
    setStatus("Server not reachable", "error");
  }
}

async function loadSettingsMeta() {
  if (!cjKeyMeta) return;
  try {
    const res = await api("/api/keys");
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Could not read the saved key.");
    if (data.exists) markKeyMeta(`Saved ✓ · key ${data.fingerprint}…`, "is-ok");
    else markKeyMeta("No API key yet — paste your CJdropshipping API Key below.", "is-warn");
  } catch {
    markKeyMeta("Could not reach the server to read your key.", "is-warn");
  }
}

function openSettings() {
  if (!settingsModal) return;
  settingsModal.hidden = false;
  if (cjKeyInput) cjKeyInput.value = "";
  setSettingsStatus("");
  loadSettingsMeta();
  if (cjKeyInput) cjKeyInput.focus();
}

if (settingsBtn) settingsBtn.addEventListener("click", openSettings);
if (settingsCloseBtn) settingsCloseBtn.addEventListener("click", () => { settingsModal.hidden = true; });
if (settingsModal) {
  settingsModal.addEventListener("click", (event) => {
    if (event.target === settingsModal) settingsModal.hidden = true;
  });
}

if (cjKeyToggleBtn) {
  cjKeyToggleBtn.addEventListener("click", () => {
    const showing = cjKeyInput.type === "text";
    cjKeyInput.type = showing ? "password" : "text";
    cjKeyToggleBtn.textContent = showing ? "Show" : "Hide";
  });
}

async function postCjKey(apiKey, busyLabel, okLabel) {
  if (cjKeySaveBtn) cjKeySaveBtn.disabled = true;
  if (cjKeyRemoveBtn) cjKeyRemoveBtn.disabled = true;
  setSettingsStatus(busyLabel);
  try {
    const res = apiKey
      ? await api("/api/keys", { method: "POST", body: JSON.stringify({ apiKey }) })
      : await api("/api/keys", { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Could not save the API key.");
    if (cjKeyInput) cjKeyInput.value = "";
    if (session) session.hasCjKey = Boolean(apiKey);
    setSettingsStatus(
      apiKey
        ? `${okLabel} — key ${data.fingerprint}… stored encrypted on the server.`
        : okLabel
    );
    await loadSettingsMeta();
    refreshStatus();
    if (apiKey) setMessage("", false);
  } catch (error) {
    setSettingsStatus(error.message || "Request failed.", true);
  } finally {
    if (cjKeySaveBtn) cjKeySaveBtn.disabled = false;
    if (cjKeyRemoveBtn) cjKeyRemoveBtn.disabled = false;
  }
}

if (cjKeySaveBtn) {
  cjKeySaveBtn.addEventListener("click", () => {
    const apiKey = cjKeyInput.value.trim();
    if (!apiKey) { setSettingsStatus("Paste your CJdropshipping API Key first.", true); return; }
    postCjKey(apiKey, "Validating the key with CJ…", "Saved ✓");
  });
}

if (cjKeyRemoveBtn) {
  cjKeyRemoveBtn.addEventListener("click", () => {
    if (!confirm("Remove your saved CJ API key? You will need to paste it again.")) return;
    postCjKey("", "Removing the saved key…", "Saved key removed ✓");
  });
}

/* ── Theme (light / dark) ─────────────────────────────────── */
const THEME_KEY = "cjTheme";
function getPreferredTheme() {
  try {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === "dark" || stored === "light") return stored;
  } catch {}
  try {
    const { [THEME_KEY]: stored } = chrome.storage.local.get([THEME_KEY]) || {};
    if (stored === "dark" || stored === "light") return stored;
  } catch {}
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function setTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  try { localStorage.setItem(THEME_KEY, theme); } catch {}
  try { chrome.storage.local.set({ [THEME_KEY]: theme }); } catch {}
  if (themeToggle) themeToggle.textContent = theme === "dark" ? "☀️" : "🌙";
}
if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    setTheme(next);
  });
}
// Apply on load (before DOM is fully painted)
(function() {
  const t = getPreferredTheme();
  document.documentElement.setAttribute("data-theme", t);
  if (themeToggle) themeToggle.textContent = t === "dark" ? "☀️" : "🌙";
})();
